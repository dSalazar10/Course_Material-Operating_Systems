Use the following command to make a debug trace of your sys calls:
bye
