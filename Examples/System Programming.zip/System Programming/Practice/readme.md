Each chapter has a "Can we rewrite this?" section which include one or two c programs.
They are all left as an exercise, which he only tells us the man pages to research.
Here I attempt to rewrite them.
