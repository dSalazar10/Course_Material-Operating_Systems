These are the assignments from the class

Ch 1: calc.c

Ch 2: head.c

Ch 3: cm.c

Ch 4: rbi.c

Ch 5: timer.c

Ch 6: timer2.c

Ch 8: sh.c
