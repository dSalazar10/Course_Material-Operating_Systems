These are the provided examples from each chapter.
