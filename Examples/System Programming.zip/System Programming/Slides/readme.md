This folder includes the slides provided by the professor, as well as C code including explanations of each of the
functions that were introduced in each chapter. There are a ton of functions that were not covered as there were only 10 
weeks. Refer to "Advanced Programming in the Unix Environment" (third edition) by W. Richard Stevens and Stephen A. Rago
or refer to your local man pages for more information.
